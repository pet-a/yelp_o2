import numpy as np
import pandas as pd
from sklearn import linear_model
import matplotlib.pyplot as plt
from scipy.stats import pearsonr

"""Preparation of the dataset"""

yelp_business = pd.read_csv('~/Desktop/Yelp/yelp_business.csv')
yelp_checkin = pd.read_csv('~/Desktop/Yelp/yelp_checkin.csv')


df = yelp_checkin.groupby('business_id')['checkins'].sum()

dataset = pd.merge(df,
                 yelp_business[['business_id', 'review_count']],
                 on='business_id')
# look on the data
print(dataset.head())
print()
plt.scatter(dataset["review_count"], dataset["checkins"], color='red')
plt.title('Nb of checkins Vs Nb of checkins', fontsize=14)
plt.xlabel('Nb of reviews', fontsize=14)
plt.ylabel('Nb of checkins', fontsize=14)
plt.grid(True)
plt.show()

# calculate statistics
print("Statistics for variable Y 'Number of checkins'")
print('Mean: %.3f' % np.mean(dataset[["checkins"]]))
print('Variance: %.3f' % np.var(dataset[["checkins"]]))
print('Standard Deviation: %.3f' % np.std(dataset[["checkins"]]))
print()
print("Statistics for variable X 'Number of reviews'")
print('Mean: %.3f'% np.mean(dataset[["review_count"]])  )
print('Variance: %.3f' % np.var(dataset[["review_count"]]) )
print('Standard Deviation: %.3f' % np.std(dataset[["review_count"]]) )

# deleting the highest values in review_count row
dataset = dataset.sort_values(by='review_count', ascending=False)

print(dataset.head(15))
print()

dropped_values = dataset[dataset["review_count"] > 5000]

indexDataset = dataset[ dataset['review_count'] > 5000 ].index
final_dataset = dataset.drop(dataset[dataset['review_count'] > 5000].index)

print(final_dataset.head())
print(final_dataset.shape)
print()

# New statistics
print("New Statistics for variable Y 'Number of checkins'")
print('Mean: %.3f' % np.mean(final_dataset[["checkins"]]))
print('Variance: %.3f' % np.var(final_dataset[["checkins"]]))
print('Standard Deviation: %.3f' % np.std(final_dataset[["checkins"]]))
print()
print("New Statistics for variable X 'Number of reviews'")
print('Mean: %.3f'% np.mean(final_dataset[["review_count"]])  )
print('Variance: %.3f' % np.var(final_dataset[["review_count"]]) )
print('Standard Deviation: %.3f' % np.std(final_dataset[["review_count"]]) )


# calculate Pearson's correlation
pearsoncorr = final_dataset.corr(method = "pearson")

print("Pearson corellation")
print(pearsoncorr)
print()

"""Plotting the final data"""

log_review = np.log(final_dataset['review_count'], dtype='float64')
log_checkins = np.log(final_dataset['checkins'], dtype='float64')

plt.scatter(log_review, log_checkins, color='green')
plt.title('% of checkins Vs % of checkins', fontsize=14)
plt.xlabel('% of reviews', fontsize=14)
plt.ylabel('% of checkins', fontsize=14)
plt.grid(True)
plt.show()

"""Performing the Linear Regression"""


# Separating the data into independent and dependent variables
# Converting each dataframe into a numpy array
# since each dataframe contains only one column

x = np.array(log_review).reshape(-1, 1)
y = np.array(log_checkins).reshape(-1, 1)


regr = linear_model.LinearRegression().fit(x, y)

print('Intercept: \n', regr.intercept_)
print('Coefficients: \n', regr.coef_)
print()

"""Exploring results"""

y_pred = regr.predict(x)
plt.scatter(x, y, color ='b')
plt.plot(x, y_pred, color ='k')
plt.title('Data scatter of predicted values ', fontsize=14)
plt.xlabel('% of reviews', fontsize=14)
plt.ylabel('% of checkins', fontsize=14)
plt.show()


class Stats:
    def __init__(self, X, y, model):
            self.data = X
            self.target = y
            self.model = model
            ## degrees of freedom population dep. variable variance
            self._dft = X.shape[0] - 1
            ## degrees of freedom population error variance
            self._dfe = X.shape[0] - X.shape[1] - 1

    def sse(self):
            '''returns sum of squared errors (model vs actual)'''
            squared_errors = (self.target - self.model.predict(self.data)) ** 2
            return np.sum(squared_errors)

    def sst(self):
            '''returns total sum of squared errors (actual vs avg(actual))'''
            avg_y = np.mean(self.target)
            squared_errors = (self.target - avg_y) ** 2
            sum_sqe = np.sum(squared_errors)
            return sum_sqe

    def r_squared(self):
            '''returns calculated value of r^2'''
            return 1 - self.sse()/self.sst()

    def adj_r_squared(self):
            '''returns calculated value of adjusted r^2'''
            return 1 - (self.sse()/self._dfe) / (self.sst()/self._dft)

def pretty_print_stats(stats_obj):
    '''returns report of statistics for a given model object'''
    items = ( ('sse:', stats_obj.sse()), ('sst:', stats_obj.sst()),
             ('r^2:', stats_obj.r_squared()), ('adj_r^2:', stats_obj.adj_r_squared()) )
    for item in items:
        print('{0:8} {1:.4f}'.format(item[0], item[1]))

stats = Stats(x, y, regr)
pretty_print_stats(stats)
